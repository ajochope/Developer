//
//  GameResultViewController.h
//  Matchismo
//
//  Created by Ajo Chope on 20/08/13.
//  Copyright (c) 2013 ocallesObjective-C. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GameResultViewController : UIViewController

@end
