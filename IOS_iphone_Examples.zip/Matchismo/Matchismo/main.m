//
//  main.m
//  Matchismo
//
//  Created by Ajo Chope on 06/07/13.
//  Copyright (c) 2013 ocallesObjective-C. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CardGameAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CardGameAppDelegate class]));
    }
}
