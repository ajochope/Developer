//
//  CardGameViewController.h
//  Matchismo
//
//  Created by Ajo Chope on 06/07/13.
//  Copyright (c) 2013 ocallesObjective-C. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CardGameViewController : UIViewController

@end
