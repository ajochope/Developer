//
//  PlayingCardDeck.h
//  Matchismo
//
//  Created by Ajo Chope on 10/07/13.
//  Copyright (c) 2013 ocallesObjective-C. All rights reserved.
//

#import "Deck.h"

@interface PlayingCardDeck : Deck

@end
