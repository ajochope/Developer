//
//  WhasaViewController.h
//  Whasa_ite1
//
//  Created by chipont on 18/07/13.
//  Copyright (c) 2013 corenetworks. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AddressBook/AddressBook.h>
#import <AddressBookUI/AddressBookUI.h>

@interface WhasaViewController : UIViewController <ABPeoplePickerNavigationControllerDelegate>

@end
